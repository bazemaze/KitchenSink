# juicy-draggable
Custom element to make items draggable and droppable

[Demo](http://juicy.github.io/juicy-draggable/)

## License

MIT
