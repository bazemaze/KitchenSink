### Steps to reproduce

#### Live Demo
<!-- Fork this JSBin, or provide your own URL -->
https://jsbin.com/ligimo/3/edit?html,output

### Expected result

### Actual result

### Browsers affected

<!-- Check all that apply -->
- [ ] Chrome
- [ ] Firefox
- [ ] Edge
- [ ] Safari 9
- [ ] Safari 8
- [ ] IE 11

### Screenshot
